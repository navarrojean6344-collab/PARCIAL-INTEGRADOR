"""Entidades del dominio: preguntas, jugador y resultados."""
from modelos.pregunta import Pregunta, PreguntaMultiple, PreguntaVerdaderoFalso
from modelos.jugador import Jugador
from modelos.resultado import ResultadoRespuesta

__all__ = [
    "Pregunta",
    "PreguntaMultiple",
    "PreguntaVerdaderoFalso",
    "Jugador",
    "ResultadoRespuesta",
]
