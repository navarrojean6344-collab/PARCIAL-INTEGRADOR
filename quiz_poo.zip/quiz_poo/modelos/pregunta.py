"""Jerarquía de preguntas.

``Pregunta`` es una clase abstracta que define el contrato común. Cada tipo de
pregunta lo implementa a su manera (polimorfismo), de modo que ``Partida`` y la
interfaz trabajan con cualquier pregunta sin saber de qué tipo es.
"""
from abc import ABC, abstractmethod


class Pregunta(ABC):
    """Contrato común de todas las preguntas del juego."""

    PUNTOS_MIN = 1
    PUNTOS_MAX = 100

    def __init__(self, enunciado: str, categoria: str, puntos: int = 10):
        self._enunciado = ""
        self._categoria = ""
        self._puntos = 0
        # Se asignan mediante las propiedades para que se apliquen las validaciones.
        self.enunciado = enunciado
        self.categoria = categoria
        self.puntos = puntos

    # ----- Encapsulamiento: el estado solo cambia si el valor es válido -----
    @property
    def enunciado(self) -> str:
        return self._enunciado

    @enunciado.setter
    def enunciado(self, valor: str) -> None:
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError("El enunciado de la pregunta no puede estar vacío.")
        self._enunciado = valor.strip()

    @property
    def categoria(self) -> str:
        return self._categoria

    @categoria.setter
    def categoria(self, valor: str) -> None:
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError("La categoría de la pregunta no puede estar vacía.")
        self._categoria = valor.strip()

    @property
    def puntos(self) -> int:
        return self._puntos

    @puntos.setter
    def puntos(self, valor: int) -> None:
        if not isinstance(valor, int) or isinstance(valor, bool):
            raise ValueError("Los puntos deben ser un número entero.")
        if not self.PUNTOS_MIN <= valor <= self.PUNTOS_MAX:
            raise ValueError(
                f"Los puntos deben estar entre {self.PUNTOS_MIN} y {self.PUNTOS_MAX}."
            )
        self._puntos = valor

    # ----- Contrato abstracto -----
    @property
    @abstractmethod
    def tipo(self) -> str:
        """Nombre legible del tipo de pregunta."""

    @abstractmethod
    def opciones(self) -> list:
        """Textos de las opciones que se muestran al jugador."""

    @abstractmethod
    def evaluar(self, indice_respuesta: int) -> bool:
        """Indica si la opción elegida (por su índice) es la correcta."""

    @abstractmethod
    def respuesta_correcta(self) -> str:
        """Texto de la respuesta correcta (se usa en la revisión final)."""

    @abstractmethod
    def calcular_puntaje(self, segundos_restantes: int, segundos_totales: int) -> int:
        """Puntos que gana el jugador al acertar, según el tipo de pregunta."""

    def _validar_indice(self, indice: int) -> None:
        if not isinstance(indice, int) or isinstance(indice, bool):
            raise TypeError("El índice de la respuesta debe ser un entero.")
        if not 0 <= indice < len(self.opciones()):
            raise IndexError("La opción elegida no existe.")

    def __str__(self) -> str:
        return f"[{self.categoria}] {self.enunciado}"


class PreguntaMultiple(Pregunta):
    """Pregunta de selección múltiple. Premia la rapidez con un bono de tiempo."""

    MIN_OPCIONES = 2
    MAX_OPCIONES = 4
    BONO_MAXIMO = 5

    def __init__(self, enunciado, categoria, opciones, indice_correcto, puntos=10):
        super().__init__(enunciado, categoria, puntos)
        limpias = [str(o).strip() for o in opciones if str(o).strip()]
        if not self.MIN_OPCIONES <= len(limpias) <= self.MAX_OPCIONES:
            raise ValueError(
                f"Debe haber entre {self.MIN_OPCIONES} y {self.MAX_OPCIONES} opciones."
            )
        if len(set(o.lower() for o in limpias)) != len(limpias):
            raise ValueError("Las opciones no pueden repetirse.")
        if not isinstance(indice_correcto, int) or not 0 <= indice_correcto < len(limpias):
            raise ValueError("El índice de la opción correcta no es válido.")
        self._opciones = limpias
        self._indice_correcto = indice_correcto

    @property
    def tipo(self) -> str:
        return "Selección múltiple"

    def opciones(self) -> list:
        return list(self._opciones)  # copia: nadie modifica la lista interna

    def evaluar(self, indice_respuesta: int) -> bool:
        self._validar_indice(indice_respuesta)
        return indice_respuesta == self._indice_correcto

    def respuesta_correcta(self) -> str:
        return self._opciones[self._indice_correcto]

    def calcular_puntaje(self, segundos_restantes: int, segundos_totales: int) -> int:
        if segundos_totales <= 0:
            return self.puntos
        fraccion = max(0, min(segundos_restantes, segundos_totales)) / segundos_totales
        return self.puntos + round(self.BONO_MAXIMO * fraccion)


class PreguntaVerdaderoFalso(Pregunta):
    """Pregunta de verdadero o falso. Vale los puntos base, sin bono de tiempo."""

    def __init__(self, enunciado, categoria, es_verdadera, puntos=5):
        super().__init__(enunciado, categoria, puntos)
        if not isinstance(es_verdadera, bool):
            raise ValueError("es_verdadera debe ser True o False.")
        self._es_verdadera = es_verdadera

    @property
    def tipo(self) -> str:
        return "Verdadero o falso"

    def opciones(self) -> list:
        return ["Verdadero", "Falso"]

    def evaluar(self, indice_respuesta: int) -> bool:
        self._validar_indice(indice_respuesta)
        eligio_verdadero = indice_respuesta == 0
        return eligio_verdadero == self._es_verdadera

    def respuesta_correcta(self) -> str:
        return "Verdadero" if self._es_verdadera else "Falso"

    def calcular_puntaje(self, segundos_restantes: int, segundos_totales: int) -> int:
        return self.puntos
