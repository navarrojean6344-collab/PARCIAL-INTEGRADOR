"""Jugador de una partida."""


class Jugador:
    """Guarda el nombre y el progreso del jugador.

    El puntaje y la racha son privados: solo cambian mediante
    ``registrar_acierto`` y ``registrar_fallo``, que mantienen la coherencia
    (por ejemplo, un puntaje nunca puede ser negativo).
    """

    def __init__(self, nombre: str):
        self._nombre = ""
        self._puntaje = 0
        self._aciertos = 0
        self._fallos = 0
        self._racha = 0
        self._mejor_racha = 0
        self.nombre = nombre

    @property
    def nombre(self) -> str:
        return self._nombre

    @nombre.setter
    def nombre(self, valor: str) -> None:
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError("Escribe un nombre para poder jugar.")
        valor = valor.strip()
        if len(valor) > 20:
            raise ValueError("El nombre no puede tener más de 20 caracteres.")
        self._nombre = valor

    @property
    def puntaje(self) -> int:
        return self._puntaje

    @property
    def aciertos(self) -> int:
        return self._aciertos

    @property
    def fallos(self) -> int:
        return self._fallos

    @property
    def racha(self) -> int:
        return self._racha

    @property
    def mejor_racha(self) -> int:
        return self._mejor_racha

    def registrar_acierto(self, puntos: int) -> None:
        if puntos < 0:
            raise ValueError("Los puntos ganados no pueden ser negativos.")
        self._puntaje += puntos
        self._aciertos += 1
        self._racha += 1
        self._mejor_racha = max(self._mejor_racha, self._racha)

    def registrar_fallo(self) -> None:
        self._fallos += 1
        self._racha = 0

    def __str__(self) -> str:
        return f"{self._nombre}: {self._puntaje} puntos"
