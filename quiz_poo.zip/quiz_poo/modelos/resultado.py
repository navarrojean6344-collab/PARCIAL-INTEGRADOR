"""Resultado de responder una pregunta."""
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ResultadoRespuesta:
    """Registro inmutable de lo que ocurrió con una pregunta."""

    enunciado: str
    tipo: str
    respuesta_elegida: Optional[str]  # None si se agotó el tiempo
    respuesta_correcta: str
    acerto: bool
    puntos_ganados: int
    tiempo_agotado: bool = False
