"""Controla el estado y las reglas de una partida."""
from enum import Enum

from modelos.jugador import Jugador
from modelos.resultado import ResultadoRespuesta


class EstadoPartida(Enum):
    EN_CURSO = "en curso"
    TERMINADA = "terminada"


class Partida:
    """Coordina al jugador con las preguntas sorteadas.

    Relación de composición: la partida crea su propio ``Jugador`` y su lista de
    resultados; sin partida, esos objetos no tienen sentido.
    """

    def __init__(self, nombre_jugador: str, preguntas: list, segundos_por_pregunta: int = 15):
        if not preguntas:
            raise ValueError("Una partida necesita al menos una pregunta.")
        if segundos_por_pregunta < 3:
            raise ValueError("El tiempo por pregunta debe ser de al menos 3 segundos.")
        self._jugador = Jugador(nombre_jugador)  # composición
        self._preguntas = list(preguntas)
        self._segundos_por_pregunta = segundos_por_pregunta
        self._indice = 0
        self._resultados = []
        self._estado = EstadoPartida.EN_CURSO

    # ----- Consulta del estado -----
    @property
    def jugador(self) -> Jugador:
        return self._jugador

    @property
    def segundos_por_pregunta(self) -> int:
        return self._segundos_por_pregunta

    @property
    def estado(self) -> EstadoPartida:
        return self._estado

    @property
    def terminada(self) -> bool:
        return self._estado is EstadoPartida.TERMINADA

    @property
    def numero_pregunta(self) -> int:
        """Número (desde 1) de la pregunta actual."""
        return min(self._indice + 1, len(self._preguntas))

    @property
    def total_preguntas(self) -> int:
        return len(self._preguntas)

    @property
    def pregunta_actual(self):
        if self.terminada:
            raise RuntimeError("La partida ya terminó.")
        return self._preguntas[self._indice]

    @property
    def resultados(self) -> list:
        return list(self._resultados)

    # ----- Acciones -----
    def responder(self, indice_respuesta: int, segundos_restantes: int) -> ResultadoRespuesta:
        pregunta = self.pregunta_actual
        acerto = pregunta.evaluar(indice_respuesta)
        if acerto:
            puntos = pregunta.calcular_puntaje(segundos_restantes, self._segundos_por_pregunta)
            self._jugador.registrar_acierto(puntos)
        else:
            puntos = 0
            self._jugador.registrar_fallo()
        resultado = ResultadoRespuesta(
            enunciado=pregunta.enunciado,
            tipo=pregunta.tipo,
            respuesta_elegida=pregunta.opciones()[indice_respuesta],
            respuesta_correcta=pregunta.respuesta_correcta(),
            acerto=acerto,
            puntos_ganados=puntos,
        )
        return self._cerrar_pregunta(resultado)

    def tiempo_agotado(self) -> ResultadoRespuesta:
        """Se llama cuando el temporizador llega a cero sin respuesta."""
        pregunta = self.pregunta_actual
        self._jugador.registrar_fallo()
        resultado = ResultadoRespuesta(
            enunciado=pregunta.enunciado,
            tipo=pregunta.tipo,
            respuesta_elegida=None,
            respuesta_correcta=pregunta.respuesta_correcta(),
            acerto=False,
            puntos_ganados=0,
            tiempo_agotado=True,
        )
        return self._cerrar_pregunta(resultado)

    def _cerrar_pregunta(self, resultado: ResultadoRespuesta) -> ResultadoRespuesta:
        self._resultados.append(resultado)
        self._indice += 1
        if self._indice >= len(self._preguntas):
            self._estado = EstadoPartida.TERMINADA
        return resultado

    def porcentaje_aciertos(self) -> int:
        if not self._resultados:
            return 0
        return round(100 * self._jugador.aciertos / len(self._resultados))
