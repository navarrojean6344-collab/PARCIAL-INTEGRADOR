"""Preguntas que vienen incluidas con el juego (todo en memoria)."""
from modelos.pregunta import PreguntaMultiple, PreguntaVerdaderoFalso

PYTHON = "Python y POO"
CIENCIA = "Ciencia"
CULTURA = "Cultura general"


def crear_banco_inicial() -> list:
    """Devuelve la lista inicial de preguntas del juego."""
    return [
        # ---------------- Python y POO ----------------
        PreguntaMultiple(
            "¿Cuál es el nombre del método constructor de una clase en Python?",
            PYTHON, ["__start__", "__init__", "__create__", "__build__"], 1),
        PreguntaMultiple(
            "¿Qué función permite llamar a un método de la clase base?",
            PYTHON, ["super()", "base()", "parent()", "self.base()"], 0),
        PreguntaMultiple(
            "¿Cómo se indica por convención que un atributo no es público?",
            PYTHON, ["Con una @", "Con un # al inicio", "Con un guion bajo al inicio", "Con la palabra private"], 2),
        PreguntaMultiple(
            "¿Qué decorador convierte un método en una propiedad?",
            PYTHON, ["@staticmethod", "@classmethod", "@abstractmethod", "@property"], 3),
        PreguntaMultiple(
            "¿Qué módulo de la biblioteca estándar se usa para definir clases abstractas?",
            PYTHON, ["abc", "oop", "typing", "classes"], 0),
        PreguntaVerdaderoFalso(
            "Python permite que una clase herede de más de una clase base.",
            PYTHON, True),
        PreguntaVerdaderoFalso(
            "Una clase con métodos abstractos sin implementar se puede instanciar directamente.",
            PYTHON, False),
        # ---------------- Ciencia ----------------
        PreguntaMultiple(
            "¿Cuál es el planeta más cercano al Sol?",
            CIENCIA, ["Venus", "Mercurio", "Marte", "Tierra"], 1),
        PreguntaMultiple(
            "¿Cuál es el símbolo químico del oro?",
            CIENCIA, ["Au", "Ag", "Go", "Or"], 0),
        PreguntaMultiple(
            "¿Cuántos huesos tiene un adulto humano?",
            CIENCIA, ["186", "196", "206", "216"], 2),
        PreguntaMultiple(
            "¿Cuál es el gas más abundante en la atmósfera terrestre?",
            CIENCIA, ["Oxígeno", "Dióxido de carbono", "Argón", "Nitrógeno"], 3),
        PreguntaVerdaderoFalso(
            "A nivel del mar el agua hierve a 100 grados Celsius.",
            CIENCIA, True),
        PreguntaVerdaderoFalso(
            "El sonido viaja más rápido en el vacío que en el aire.",
            CIENCIA, False),
        # ---------------- Cultura general ----------------
        PreguntaMultiple(
            "¿Cuál es la capital de Colombia?",
            CULTURA, ["Medellín", "Cali", "Bogotá", "Barranquilla"], 2),
        PreguntaMultiple(
            "¿Cuál es el océano más grande del planeta?",
            CULTURA, ["Pacífico", "Atlántico", "Índico", "Ártico"], 0),
        PreguntaMultiple(
            "¿Quién escribió «Cien años de soledad»?",
            CULTURA, ["Mario Vargas Llosa", "Gabriel García Márquez", "Julio Cortázar", "Pablo Neruda"], 1),
        PreguntaMultiple(
            "¿Cuál es el río más importante de Colombia, que recorre el país de sur a norte?",
            CULTURA, ["Cauca", "Amazonas", "Orinoco", "Magdalena"], 3),
        PreguntaVerdaderoFalso(
            "Australia es al mismo tiempo un país y un continente.",
            CULTURA, True),
        PreguntaVerdaderoFalso(
            "La Gran Muralla China se ve a simple vista desde la Luna.",
            CULTURA, False),
    ]
