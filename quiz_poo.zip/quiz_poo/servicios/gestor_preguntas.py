"""Administra el banco de preguntas."""
import random
from typing import Optional

from modelos.pregunta import Pregunta
from servicios.banco_preguntas import crear_banco_inicial

TODAS = "Todas las categorías"


class GestorPreguntas:
    """Guarda las preguntas y permite consultarlas y sortearlas.

    Relación de agregación: el gestor *tiene* preguntas, pero estas son objetos
    independientes que podrían existir (o crearse) fuera de él.
    """

    def __init__(self, preguntas: Optional[list] = None):
        self._preguntas = []
        for pregunta in (preguntas if preguntas is not None else crear_banco_inicial()):
            self.agregar(pregunta)

    def agregar(self, pregunta: Pregunta) -> None:
        if not isinstance(pregunta, Pregunta):
            raise TypeError("Solo se pueden agregar objetos de tipo Pregunta.")
        if any(p.enunciado.lower() == pregunta.enunciado.lower() for p in self._preguntas):
            raise ValueError("Ya existe una pregunta con ese enunciado.")
        self._preguntas.append(pregunta)

    def categorias(self) -> list:
        return sorted({p.categoria for p in self._preguntas})

    def total(self, categoria: str = TODAS) -> int:
        return len(self.por_categoria(categoria))

    def por_categoria(self, categoria: str = TODAS) -> list:
        if categoria == TODAS:
            return list(self._preguntas)
        return [p for p in self._preguntas if p.categoria == categoria]

    def sortear(self, categoria: str, cantidad: int, generador=None) -> list:
        """Elige ``cantidad`` preguntas distintas de la categoría, en orden aleatorio."""
        if cantidad < 1:
            raise ValueError("La cantidad de preguntas debe ser al menos 1.")
        disponibles = self.por_categoria(categoria)
        if not disponibles:
            raise ValueError("No hay preguntas en esa categoría.")
        if cantidad > len(disponibles):
            raise ValueError(
                f"Solo hay {len(disponibles)} preguntas disponibles en esa categoría."
            )
        azar = generador or random
        return azar.sample(disponibles, cantidad)
