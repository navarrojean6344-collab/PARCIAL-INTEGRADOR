"""Cuenta regresiva basada en callbacks, independiente de la interfaz."""
from typing import Callable


class Temporizador:
    """Cuenta hacia atrás de segundo en segundo.

    No conoce Tkinter: recibe dos funciones (``programar`` y ``cancelar``) que la
    interfaz le proporciona con ``widget.after`` y ``widget.after_cancel``. Así la
    clase se puede probar sin ventana y la interfaz sigue respondiendo mientras
    corre el tiempo.
    """

    def __init__(
        self,
        programar: Callable,
        cancelar: Callable,
        al_cambiar: Callable[[int], None],
        al_terminar: Callable[[], None],
    ):
        self._programar = programar
        self._cancelar = cancelar
        self._al_cambiar = al_cambiar
        self._al_terminar = al_terminar
        self._restantes = 0
        self._id_pendiente = None
        self._activo = False

    @property
    def restantes(self) -> int:
        return self._restantes

    @property
    def activo(self) -> bool:
        return self._activo

    def iniciar(self, segundos: int) -> None:
        if segundos < 1:
            raise ValueError("La duración debe ser de al menos 1 segundo.")
        self.detener()
        self._restantes = segundos
        self._activo = True
        self._al_cambiar(self._restantes)
        self._id_pendiente = self._programar(1000, self._tick)

    def detener(self) -> None:
        if self._id_pendiente is not None:
            self._cancelar(self._id_pendiente)
        self._id_pendiente = None
        self._activo = False

    def _tick(self) -> None:
        self._id_pendiente = None
        if not self._activo:
            return
        self._restantes -= 1
        self._al_cambiar(self._restantes)
        if self._restantes <= 0:
            self._activo = False
            self._al_terminar()
        else:
            self._id_pendiente = self._programar(1000, self._tick)
