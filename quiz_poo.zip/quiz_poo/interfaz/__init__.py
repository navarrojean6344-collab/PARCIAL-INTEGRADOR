"""Interfaz gráfica (Tkinter)."""
