"""Clase base de las pantallas de la aplicación."""
import tkinter as tk

from interfaz import estilos


class Pantalla(tk.Frame):
    """Marco que se muestra u oculta dentro de la ventana principal.

    Las pantallas hijas construyen sus controles en ``_construir`` y solo se
    comunican con la lógica a través de los callbacks que reciben.
    """

    def __init__(self, contenedor):
        super().__init__(contenedor, bg=estilos.FONDO)
        self._construir()

    def _construir(self) -> None:
        raise NotImplementedError("Cada pantalla debe construir sus controles.")

    def mostrar(self) -> None:
        self.pack(fill="both", expand=True)

    def ocultar(self) -> None:
        self.pack_forget()

    # ----- Utilidades para crear controles con el mismo estilo -----
    def _boton(self, padre, texto, comando, color=estilos.PRIMARIO):
        return tk.Button(
            padre, text=texto, command=comando, bg=color, fg="white",
            activebackground=estilos.PRIMARIO_OSCURO, activeforeground="white",
            font=estilos.FUENTE_BOTON, relief="flat", cursor="hand2",
            padx=16, pady=8,
        )

    def _etiqueta(self, padre, texto="", fuente=estilos.FUENTE_NORMAL, color=estilos.TEXTO, **extra):
        return tk.Label(padre, text=texto, font=fuente, fg=color, bg=estilos.FONDO, **extra)
