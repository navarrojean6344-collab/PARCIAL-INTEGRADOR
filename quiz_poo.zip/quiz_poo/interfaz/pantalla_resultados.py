"""Pantalla final con el resumen y la revisión de respuestas."""
import tkinter as tk
from tkinter import ttk

from interfaz import estilos
from interfaz.pantalla import Pantalla


class PantallaResultados(Pantalla):
    def __init__(self, contenedor, al_jugar_de_nuevo, al_salir):
        self._al_jugar_de_nuevo = al_jugar_de_nuevo
        self._al_salir = al_salir
        super().__init__(contenedor)

    def _construir(self) -> None:
        self._etiqueta(self, "Fin de la partida", estilos.FUENTE_TITULO, estilos.PRIMARIO).pack(pady=(24, 4))
        self._resumen = self._etiqueta(self, "", estilos.FUENTE_SUBTITULO)
        self._resumen.pack()
        self._detalle = self._etiqueta(self, "", estilos.FUENTE_NORMAL, estilos.TEXTO_SUAVE)
        self._detalle.pack(pady=(4, 12))

        marco = tk.Frame(self, bg=estilos.FONDO)
        marco.pack(fill="both", expand=True, padx=30)
        columnas = ("n", "pregunta", "tu_respuesta", "correcta", "puntos")
        self._tabla = ttk.Treeview(marco, columns=columnas, show="headings", height=8)
        for clave, titulo, ancho in (
            ("n", "#", 30), ("pregunta", "Pregunta", 280), ("tu_respuesta", "Tu respuesta", 120),
            ("correcta", "Correcta", 120), ("puntos", "Puntos", 60),
        ):
            self._tabla.heading(clave, text=titulo)
            self._tabla.column(clave, width=ancho, anchor="w" if clave == "pregunta" else "center")
        self._tabla.tag_configure("acierto", foreground=estilos.ACIERTO)
        self._tabla.tag_configure("fallo", foreground=estilos.FALLO)
        barra = ttk.Scrollbar(marco, orient="vertical", command=self._tabla.yview)
        self._tabla.configure(yscrollcommand=barra.set)
        self._tabla.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")

        botones = tk.Frame(self, bg=estilos.FONDO)
        botones.pack(pady=16)
        self._boton(botones, "Jugar de nuevo", self._al_jugar_de_nuevo).pack(side="left", padx=6)
        self._boton(botones, "Salir", self._al_salir, color=estilos.TEXTO_SUAVE).pack(side="left", padx=6)

    def mostrar_partida(self, partida) -> None:
        jugador = partida.jugador
        self._resumen.configure(text=f"{jugador.nombre}: {jugador.puntaje} puntos")
        self._detalle.configure(
            text=f"{jugador.aciertos} aciertos · {jugador.fallos} fallos · "
                 f"{partida.porcentaje_aciertos()}% de efectividad · mejor racha: {jugador.mejor_racha}")
        self._tabla.delete(*self._tabla.get_children())
        for numero, r in enumerate(partida.resultados, start=1):
            elegida = "(sin respuesta)" if r.respuesta_elegida is None else r.respuesta_elegida
            self._tabla.insert(
                "", "end", tags=("acierto" if r.acerto else "fallo",),
                values=(numero, r.enunciado, elegida, r.respuesta_correcta, r.puntos_ganados))
