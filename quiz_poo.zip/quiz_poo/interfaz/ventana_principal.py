"""Ventana principal: conecta las pantallas con la lógica de la aplicación."""
import tkinter as tk
from tkinter import messagebox

from interfaz import estilos
from interfaz.dialogo_pregunta import DialogoNuevaPregunta
from interfaz.pantalla_inicio import PantallaInicio
from interfaz.pantalla_juego import PantallaJuego
from interfaz.pantalla_resultados import PantallaResultados
from servicios.gestor_preguntas import TODAS, GestorPreguntas
from servicios.partida import Partida
from servicios.temporizador import Temporizador

PAUSA_ENTRE_PREGUNTAS_MS = 1500


class VentanaPrincipal(tk.Tk):
    """Controlador de la interfaz.

    Recibe eventos (clics, teclas, tiempo) y los traduce en llamadas a las
    clases de ``servicios`` y ``modelos``. Las reglas del juego no están aquí.
    """

    def __init__(self, gestor: GestorPreguntas):
        super().__init__()
        self.title("Quiz POO")
        self.geometry("760x620")
        self.minsize(700, 580)
        self.configure(bg=estilos.FONDO)

        self._gestor = gestor
        self._partida = None
        self._indice_elegido = None

        # El temporizador usa after/after_cancel de esta misma ventana (callbacks).
        self._temporizador = Temporizador(
            programar=self.after,
            cancelar=self.after_cancel,
            al_cambiar=self._al_cambiar_tiempo,
            al_terminar=self._al_agotarse_el_tiempo,
        )

        self._inicio = PantallaInicio(
            self, categorias=self._lista_categorias, total_por_categoria=self._gestor.total,
            al_comenzar=self._iniciar_partida, al_agregar_pregunta=self._abrir_dialogo)
        self._juego = PantallaJuego(self, al_responder=self._responder)
        self._resultados = PantallaResultados(
            self, al_jugar_de_nuevo=self._volver_al_inicio, al_salir=self._salir)

        self._pantalla_actual = None
        self._cambiar_a(self._inicio)
        self.protocol("WM_DELETE_WINDOW", self._salir)

    # ----- Navegación -----
    def _cambiar_a(self, pantalla) -> None:
        if self._pantalla_actual is not None:
            self._pantalla_actual.ocultar()
        self._pantalla_actual = pantalla
        pantalla.mostrar()

    def _lista_categorias(self) -> list:
        return [TODAS] + self._gestor.categorias()

    def _volver_al_inicio(self) -> None:
        self._inicio.reiniciar()
        self._inicio.actualizar_categorias()
        self._cambiar_a(self._inicio)

    # ----- Eventos de la pantalla de inicio -----
    def _iniciar_partida(self, nombre, categoria, cantidad_texto, segundos_texto) -> None:
        try:
            cantidad = int(cantidad_texto)
            segundos = int(segundos_texto)
        except ValueError:
            messagebox.showerror("Datos inválidos", "La cantidad de preguntas y los segundos deben ser números enteros.")
            return
        try:
            preguntas = self._gestor.sortear(categoria, cantidad)
            self._partida = Partida(nombre, preguntas, segundos)
        except ValueError as error:  # nombre vacío, pocas preguntas, tiempo muy corto…
            messagebox.showwarning("No se puede comenzar", str(error))
            return
        self._cambiar_a(self._juego)
        self._mostrar_pregunta_actual()

    def _abrir_dialogo(self) -> None:
        DialogoNuevaPregunta(self, self._gestor.categorias(), self._guardar_pregunta)

    def _guardar_pregunta(self, pregunta) -> None:
        self._gestor.agregar(pregunta)  # puede lanzar ValueError (duplicada): lo atiende el diálogo
        self._inicio.actualizar_categorias()

    # ----- Flujo de la partida -----
    def _mostrar_pregunta_actual(self) -> None:
        partida = self._partida
        self._indice_elegido = None
        self._juego.mostrar_pregunta(
            partida.pregunta_actual, partida.numero_pregunta,
            partida.total_preguntas, partida.jugador.puntaje)
        self._temporizador.iniciar(partida.segundos_por_pregunta)

    def _responder(self, indice: int) -> None:
        """Callback de los botones de opción."""
        if self._partida is None or not self._temporizador.activo:
            return  # ya se respondió o se acabó el tiempo
        restantes = self._temporizador.restantes
        self._temporizador.detener()
        self._indice_elegido = indice
        resultado = self._partida.responder(indice, restantes)
        self._finalizar_pregunta(resultado)

    def _al_cambiar_tiempo(self, segundos: int) -> None:
        self._juego.actualizar_tiempo(segundos)

    def _al_agotarse_el_tiempo(self) -> None:
        resultado = self._partida.tiempo_agotado()
        self._finalizar_pregunta(resultado)

    def _finalizar_pregunta(self, resultado) -> None:
        self._juego.mostrar_resultado(resultado, self._indice_elegido)
        self._juego.actualizar_puntaje(self._partida.jugador.puntaje)
        self.after(PAUSA_ENTRE_PREGUNTAS_MS, self._continuar)

    def _continuar(self) -> None:
        if self._partida.terminada:
            self._resultados.mostrar_partida(self._partida)
            self._cambiar_a(self._resultados)
        else:
            self._mostrar_pregunta_actual()

    def _salir(self) -> None:
        self._temporizador.detener()
        self.destroy()
