"""Colores y fuentes compartidos por todas las pantallas."""

FONDO = "#f4f6fb"
PRIMARIO = "#3b5bdb"
PRIMARIO_OSCURO = "#2f4ac0"
TEXTO = "#212529"
TEXTO_SUAVE = "#6c757d"
ACIERTO = "#2f9e44"
FALLO = "#e03131"
ADVERTENCIA = "#f08c00"

FUENTE_TITULO = ("Segoe UI", 22, "bold")
FUENTE_SUBTITULO = ("Segoe UI", 13)
FUENTE_NORMAL = ("Segoe UI", 11)
FUENTE_PREGUNTA = ("Segoe UI", 15, "bold")
FUENTE_BOTON = ("Segoe UI", 11, "bold")
FUENTE_TIEMPO = ("Segoe UI", 20, "bold")
