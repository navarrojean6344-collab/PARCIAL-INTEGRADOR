"""Ventana para que el usuario agregue sus propias preguntas."""
import tkinter as tk
from tkinter import messagebox, ttk

from interfaz import estilos
from modelos.pregunta import PreguntaMultiple, PreguntaVerdaderoFalso

MULTIPLE = "multiple"
VERDADERO_FALSO = "vf"


class DialogoNuevaPregunta(tk.Toplevel):
    """Recoge los datos y crea el objeto Pregunta; ``al_guardar`` lo registra."""

    def __init__(self, ventana, categorias, al_guardar):
        super().__init__(ventana)
        self.title("Agregar pregunta")
        self.configure(bg=estilos.FONDO, padx=24, pady=18)
        self.resizable(False, False)
        self.transient(ventana)
        self.grab_set()  # modal: bloquea la ventana principal mientras está abierto

        self._al_guardar = al_guardar
        self._tipo = tk.StringVar(value=MULTIPLE)
        self._categoria = tk.StringVar()
        self._enunciado = tk.StringVar()
        self._opciones = [tk.StringVar() for _ in range(4)]
        self._correcta = tk.IntVar(value=0)
        self._es_verdadera = tk.BooleanVar(value=True)

        fila = 0
        tk.Label(self, text="Categoría", bg=estilos.FONDO, font=estilos.FUENTE_NORMAL).grid(row=fila, column=0, sticky="w", pady=4)
        ttk.Combobox(self, textvariable=self._categoria, values=categorias, width=30).grid(row=fila, column=1, columnspan=2, pady=4)

        fila += 1
        tk.Label(self, text="Enunciado", bg=estilos.FONDO, font=estilos.FUENTE_NORMAL).grid(row=fila, column=0, sticky="w", pady=4)
        ttk.Entry(self, textvariable=self._enunciado, width=33).grid(row=fila, column=1, columnspan=2, pady=4)

        fila += 1
        tk.Label(self, text="Tipo", bg=estilos.FONDO, font=estilos.FUENTE_NORMAL).grid(row=fila, column=0, sticky="w", pady=4)
        marco_tipo = tk.Frame(self, bg=estilos.FONDO)
        marco_tipo.grid(row=fila, column=1, columnspan=2, sticky="w")
        for texto, valor in (("Selección múltiple", MULTIPLE), ("Verdadero/Falso", VERDADERO_FALSO)):
            tk.Radiobutton(marco_tipo, text=texto, variable=self._tipo, value=valor, bg=estilos.FONDO,
                           command=self._cambiar_tipo).pack(side="left", padx=(0, 10))

        # Zona de selección múltiple
        self._marco_multiple = tk.Frame(self, bg=estilos.FONDO)
        self._marco_multiple.grid(row=fila + 1, column=0, columnspan=3, sticky="w")
        tk.Label(self._marco_multiple, text="Escribe de 2 a 4 opciones y marca la correcta:",
                 bg=estilos.FONDO, fg=estilos.TEXTO_SUAVE).grid(row=0, column=0, columnspan=2, sticky="w", pady=(6, 2))
        for i, variable in enumerate(self._opciones):
            tk.Radiobutton(self._marco_multiple, variable=self._correcta, value=i, bg=estilos.FONDO).grid(row=i + 1, column=0)
            ttk.Entry(self._marco_multiple, textvariable=variable, width=36).grid(row=i + 1, column=1, pady=2)

        # Zona de verdadero/falso
        self._marco_vf = tk.Frame(self, bg=estilos.FONDO)
        tk.Label(self._marco_vf, text="La afirmación es:", bg=estilos.FONDO).pack(side="left", pady=8)
        tk.Radiobutton(self._marco_vf, text="Verdadera", variable=self._es_verdadera, value=True, bg=estilos.FONDO).pack(side="left", padx=8)
        tk.Radiobutton(self._marco_vf, text="Falsa", variable=self._es_verdadera, value=False, bg=estilos.FONDO).pack(side="left")
        self._fila_vf = fila + 1

        botones = tk.Frame(self, bg=estilos.FONDO)
        botones.grid(row=fila + 2, column=0, columnspan=3, pady=(14, 0))
        tk.Button(botones, text="Guardar", command=self._guardar, bg=estilos.PRIMARIO, fg="white",
                  relief="flat", padx=14, pady=6, font=estilos.FUENTE_BOTON).pack(side="left", padx=6)
        tk.Button(botones, text="Cancelar", command=self.destroy, relief="flat", padx=14, pady=6,
                  font=estilos.FUENTE_BOTON).pack(side="left", padx=6)

        self.bind("<Escape>", lambda _e: self.destroy())

    def _cambiar_tipo(self) -> None:
        if self._tipo.get() == MULTIPLE:
            self._marco_vf.grid_forget()
            self._marco_multiple.grid(row=self._fila_vf, column=0, columnspan=3, sticky="w")
        else:
            self._marco_multiple.grid_forget()
            self._marco_vf.grid(row=self._fila_vf, column=0, columnspan=3, sticky="w")

    def _guardar(self) -> None:
        try:
            if self._tipo.get() == MULTIPLE:
                # Solo cuentan las opciones escritas; se recalcula el índice de la correcta.
                escritas = [(i, v.get().strip()) for i, v in enumerate(self._opciones) if v.get().strip()]
                textos = [t for _, t in escritas]
                posicion = [i for i, _ in escritas].index(self._correcta.get()) \
                    if self._correcta.get() in [i for i, _ in escritas] else -1
                pregunta = PreguntaMultiple(self._enunciado.get(), self._categoria.get(), textos, posicion)
            else:
                pregunta = PreguntaVerdaderoFalso(self._enunciado.get(), self._categoria.get(),
                                                  self._es_verdadera.get())
            self._al_guardar(pregunta)
        except (ValueError, TypeError) as error:
            messagebox.showerror("No se pudo guardar", str(error), parent=self)
            return
        messagebox.showinfo("Listo", "La pregunta se agregó al banco.", parent=self)
        self.destroy()
