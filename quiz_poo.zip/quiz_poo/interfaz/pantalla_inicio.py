"""Pantalla de bienvenida: nombre, categoría y cantidad de preguntas."""
import tkinter as tk
from tkinter import ttk

from interfaz import estilos
from interfaz.pantalla import Pantalla


class PantallaInicio(Pantalla):
    def __init__(self, contenedor, categorias, total_por_categoria,
                 al_comenzar, al_agregar_pregunta):
        # Se guardan antes de llamar a super().__init__, que construye los controles.
        self._categorias = categorias
        self._total_por_categoria = total_por_categoria
        self._al_comenzar = al_comenzar
        self._al_agregar_pregunta = al_agregar_pregunta
        super().__init__(contenedor)

    def _construir(self) -> None:
        caja = tk.Frame(self, bg=estilos.FONDO)
        caja.place(relx=0.5, rely=0.5, anchor="center")

        self._etiqueta(caja, "🎯 Quiz POO", estilos.FUENTE_TITULO, estilos.PRIMARIO).pack(pady=(0, 4))
        self._etiqueta(caja, "Pon a prueba tus conocimientos", estilos.FUENTE_SUBTITULO,
                       estilos.TEXTO_SUAVE).pack(pady=(0, 24))

        formulario = tk.Frame(caja, bg=estilos.FONDO)
        formulario.pack()

        self._etiqueta(formulario, "Tu nombre").grid(row=0, column=0, sticky="w", pady=6)
        self._nombre = tk.StringVar()
        entrada = ttk.Entry(formulario, textvariable=self._nombre, width=24, font=estilos.FUENTE_NORMAL)
        entrada.grid(row=0, column=1, padx=(12, 0), pady=6)
        entrada.focus_set()
        entrada.bind("<Return>", lambda _e: self._comenzar())  # evento de teclado

        self._etiqueta(formulario, "Categoría").grid(row=1, column=0, sticky="w", pady=6)
        self._categoria = tk.StringVar()
        self._combo = ttk.Combobox(formulario, textvariable=self._categoria, state="readonly",
                                   width=22, font=estilos.FUENTE_NORMAL)
        self._combo.grid(row=1, column=1, padx=(12, 0), pady=6)
        self._combo.bind("<<ComboboxSelected>>", lambda _e: self._actualizar_maximo())

        self._etiqueta(formulario, "Preguntas").grid(row=2, column=0, sticky="w", pady=6)
        self._cantidad = tk.StringVar(value="5")
        self._spin = ttk.Spinbox(formulario, from_=1, to=10, textvariable=self._cantidad,
                                 width=6, font=estilos.FUENTE_NORMAL)
        self._spin.grid(row=2, column=1, padx=(12, 0), pady=6, sticky="w")

        self._etiqueta(formulario, "Segundos por pregunta").grid(row=3, column=0, sticky="w", pady=6)
        self._segundos = tk.StringVar(value="15")
        ttk.Spinbox(formulario, from_=5, to=60, increment=5, textvariable=self._segundos,
                    width=6, font=estilos.FUENTE_NORMAL).grid(row=3, column=1, padx=(12, 0), pady=6, sticky="w")

        self._boton(caja, "Comenzar", self._comenzar).pack(pady=(24, 8), fill="x")
        self._boton(caja, "Agregar una pregunta", self._al_agregar_pregunta,
                    color=estilos.TEXTO_SUAVE).pack(fill="x")

        self.actualizar_categorias()

    # ----- Métodos públicos que usa la ventana principal -----
    def actualizar_categorias(self) -> None:
        """Recarga las categorías (por ejemplo, tras agregar una pregunta nueva)."""
        opciones = self._categorias()
        self._combo["values"] = opciones
        if self._categoria.get() not in opciones:
            self._categoria.set(opciones[0])
        self._actualizar_maximo()

    def reiniciar(self) -> None:
        self._nombre.set("")

    # ----- Eventos -----
    def _actualizar_maximo(self) -> None:
        maximo = max(1, self._total_por_categoria(self._categoria.get()))
        self._spin.configure(to=maximo)
        try:
            if int(self._cantidad.get()) > maximo:
                self._cantidad.set(str(maximo))
        except ValueError:
            self._cantidad.set(str(min(5, maximo)))

    def _comenzar(self) -> None:
        # La pantalla solo recoge los datos; la validación real está en las clases.
        self._al_comenzar(self._nombre.get(), self._categoria.get(),
                          self._cantidad.get(), self._segundos.get())
