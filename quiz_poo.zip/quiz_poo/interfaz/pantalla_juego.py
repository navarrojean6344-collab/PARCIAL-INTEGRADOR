"""Pantalla donde se responde cada pregunta."""
import tkinter as tk

from interfaz import estilos
from interfaz.pantalla import Pantalla


class PantallaJuego(Pantalla):
    def __init__(self, contenedor, al_responder):
        self._al_responder = al_responder
        self._botones = []
        super().__init__(contenedor)

    def _construir(self) -> None:
        barra = tk.Frame(self, bg=estilos.FONDO)
        barra.pack(fill="x", padx=30, pady=(20, 0))
        self._progreso = self._etiqueta(barra, "", estilos.FUENTE_SUBTITULO, estilos.TEXTO_SUAVE)
        self._progreso.pack(side="left")
        self._puntaje = self._etiqueta(barra, "", estilos.FUENTE_SUBTITULO, estilos.PRIMARIO)
        self._puntaje.pack(side="right")

        self._tiempo = self._etiqueta(self, "", estilos.FUENTE_TIEMPO, estilos.PRIMARIO)
        self._tiempo.pack(pady=(14, 0))

        self._categoria = self._etiqueta(self, "", estilos.FUENTE_NORMAL, estilos.TEXTO_SUAVE)
        self._categoria.pack(pady=(10, 0))
        self._enunciado = self._etiqueta(self, "", estilos.FUENTE_PREGUNTA, wraplength=640, justify="center")
        self._enunciado.pack(padx=30, pady=(4, 18))

        self._zona_opciones = tk.Frame(self, bg=estilos.FONDO)
        self._zona_opciones.pack(fill="x", padx=60)

        self._mensaje = self._etiqueta(self, "", estilos.FUENTE_SUBTITULO, wraplength=640)
        self._mensaje.pack(pady=18)

    # ----- Métodos públicos que usa la ventana principal -----
    def mostrar_pregunta(self, pregunta, numero, total, puntaje) -> None:
        self._progreso.configure(text=f"Pregunta {numero} de {total}")
        self.actualizar_puntaje(puntaje)
        self._categoria.configure(text=f"{pregunta.categoria} · {pregunta.tipo}")
        self._enunciado.configure(text=pregunta.enunciado)
        self._mensaje.configure(text="")

        for boton in self._botones:
            boton.destroy()
        self._botones = []
        # Polimorfismo: la pantalla solo pide las opciones; no le importa el tipo.
        for indice, texto in enumerate(pregunta.opciones()):
            boton = tk.Button(
                self._zona_opciones, text=texto, font=estilos.FUENTE_BOTON,
                bg="white", fg=estilos.TEXTO, relief="solid", bd=1, cursor="hand2",
                pady=10, wraplength=560,
                command=lambda i=indice: self._al_responder(i),
            )
            boton.pack(fill="x", pady=5)
            self._botones.append(boton)

    def actualizar_tiempo(self, segundos: int) -> None:
        color = estilos.FALLO if segundos <= 5 else estilos.PRIMARIO
        self._tiempo.configure(text=f"⏱ {segundos} s", fg=color)

    def actualizar_puntaje(self, puntaje: int) -> None:
        self._puntaje.configure(text=f"Puntaje: {puntaje}")

    def bloquear_opciones(self) -> None:
        for boton in self._botones:
            boton.configure(state="disabled")

    def mostrar_resultado(self, resultado, indice_elegido) -> None:
        """Pinta de verde la correcta y de rojo la elegida si falló."""
        self.bloquear_opciones()
        for indice, boton in enumerate(self._botones):
            if boton.cget("text") == resultado.respuesta_correcta:
                boton.configure(bg=estilos.ACIERTO, fg="white", disabledforeground="white")
            elif indice == indice_elegido and not resultado.acerto:
                boton.configure(bg=estilos.FALLO, fg="white", disabledforeground="white")

        if resultado.acerto:
            self._mensaje.configure(text=f"¡Correcto! +{resultado.puntos_ganados} puntos",
                                    fg=estilos.ACIERTO)
        elif resultado.tiempo_agotado:
            self._mensaje.configure(
                text=f"Se acabó el tiempo. Era: {resultado.respuesta_correcta}", fg=estilos.ADVERTENCIA)
        else:
            self._mensaje.configure(
                text=f"Incorrecto. Era: {resultado.respuesta_correcta}", fg=estilos.FALLO)
