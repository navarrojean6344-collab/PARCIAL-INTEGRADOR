# Informe técnico — Quiz POO

## 1. Análisis del problema

**Necesidad.** Practicar con listas de preguntas en papel no da retroalimentación inmediata ni mide el desempeño. Se plantea una aplicación de escritorio que convierta la práctica en un juego con puntaje, tiempo límite y revisión de errores.

**Público objetivo.** Estudiantes que quieren repasar contenidos (en particular, conceptos de Python y POO) y cualquier persona que disfrute de un juego de preguntas.

**Funcionalidades.**
1. Configurar y comenzar una partida (nombre, categoría, cantidad y tiempo).
2. Responder preguntas de selección múltiple y de verdadero o falso con puntaje.
3. Temporizador por pregunta.
4. Resumen final con revisión de respuestas.
5. Agregar preguntas propias.

**Limitaciones.** Los datos viven solo en memoria (el enunciado no exige persistencia), por lo que las preguntas agregadas se pierden al cerrar. Es un juego de un solo jugador y sin sonido.

## 2. Diseño inicial

Se partió de los sustantivos del problema para identificar las clases y asignarles una única responsabilidad:

| Clase | Responsabilidad |
|-------|-----------------|
| `Pregunta` (abstracta) | Define lo que toda pregunta debe saber hacer: mostrar opciones, evaluarse y calcular su puntaje. |
| `PreguntaMultiple` | Pregunta con 2 a 4 opciones; da bono por rapidez. |
| `PreguntaVerdaderoFalso` | Afirmación que se responde con Verdadero o Falso; sin bono. |
| `Jugador` | Guarda nombre, puntaje, aciertos, fallos y rachas. |
| `ResultadoRespuesta` | Registro inmutable de lo ocurrido con una pregunta. |
| `GestorPreguntas` | Administra el banco: agregar, filtrar por categoría y sortear. |
| `Partida` | Aplica las reglas: pregunta actual, responder, tiempo agotado, fin del juego. |
| `Temporizador` | Cuenta regresiva con callbacks, sin depender de la interfaz. |
| `VentanaPrincipal` y `Pantalla*` | Mostrar información y capturar eventos del usuario. |

### Diagrama de clases

```mermaid
classDiagram
    class Pregunta {
        <<abstract>>
        -str _enunciado
        -str _categoria
        -int _puntos
        +tipo str*
        +opciones() list*
        +evaluar(indice) bool*
        +respuesta_correcta() str*
        +calcular_puntaje(restantes, totales) int*
    }
    class PreguntaMultiple
    class PreguntaVerdaderoFalso
    class Jugador {
        -str _nombre
        -int _puntaje
        +registrar_acierto(puntos)
        +registrar_fallo()
    }
    class GestorPreguntas {
        +agregar(pregunta)
        +categorias() list
        +sortear(categoria, cantidad) list
    }
    class Partida {
        +responder(indice, restantes)
        +tiempo_agotado()
    }
    class Temporizador {
        +iniciar(segundos)
        +detener()
    }
    class VentanaPrincipal
    class Pantalla

    Pregunta <|-- PreguntaMultiple
    Pregunta <|-- PreguntaVerdaderoFalso
    GestorPreguntas o-- Pregunta : agregación
    Partida *-- Jugador : composición
    Partida --> Pregunta : usa
    VentanaPrincipal --> Partida : asociación
    VentanaPrincipal --> GestorPreguntas : asociación
    VentanaPrincipal --> Temporizador : asociación
    Pantalla <|-- PantallaInicio
    Pantalla <|-- PantallaJuego
    Pantalla <|-- PantallaResultados
    VentanaPrincipal *-- Pantalla : contiene
```

## 3. Arquitectura

El código se separó en tres capas para que la lógica no dependa de la interfaz:

- **`modelos/`**: entidades del dominio. No importan Tkinter.
- **`servicios/`**: reglas del juego (`Partida`), banco de preguntas y `Temporizador`. Tampoco importan Tkinter, por eso se pueden probar con pytest sin abrir ventanas.
- **`interfaz/`**: ventanas y controles. `VentanaPrincipal` actúa como controlador: recibe eventos, llama a `servicios` y le ordena a las pantallas qué mostrar.

Flujo de una jugada:

```
Clic en opción → PantallaJuego (callback) → VentanaPrincipal._responder
   → Partida.responder → Pregunta.evaluar / calcular_puntaje → Jugador.registrar_acierto
   → ResultadoRespuesta → PantallaJuego.mostrar_resultado
```

Las pantallas nunca contienen reglas del juego: solo muestran datos y reenvían eventos.

## 4. Aplicación de POO

| Concepto | Clase o método | Archivo | Explicación |
|----------|----------------|---------|-------------|
| Clases y objetos | `Jugador`, `Partida`, `GestorPreguntas`, `Temporizador` | `modelos/jugador.py`, `servicios/*.py` | Cada una tiene un constructor `__init__` y una responsabilidad clara; `VentanaPrincipal` crea los objetos y los hace colaborar. |
| Encapsulamiento | `Pregunta.enunciado`, `Pregunta.puntos` (`@property` con setter) | `modelos/pregunta.py` | El setter rechaza textos vacíos y puntos fuera de 1–100. El estado nunca queda inválido. |
| Encapsulamiento | `Jugador._puntaje`, `_racha` | `modelos/jugador.py` | Solo cambian con `registrar_acierto` / `registrar_fallo`; asignar `jugador.puntaje = 999` lanza error (hay una prueba). |
| Encapsulamiento | `PreguntaMultiple.opciones()` | `modelos/pregunta.py` | Devuelve una copia de la lista, así nadie altera las opciones internas. |
| Herencia | `PreguntaMultiple`, `PreguntaVerdaderoFalso` | `modelos/pregunta.py` | Reutilizan enunciado, categoría, puntos y sus validaciones de `Pregunta` mediante `super().__init__`, y especializan cómo se evalúan. |
| Herencia | `PantallaInicio`, `PantallaJuego`, `PantallaResultados` | `interfaz/pantalla*.py` | Heredan de `Pantalla` (a su vez de `tk.Frame`) el `mostrar`, `ocultar` y la creación de botones y etiquetas. |
| Polimorfismo | `evaluar()`, `opciones()`, `calcular_puntaje()` | `modelos/pregunta.py` | `Partida` y `PantallaJuego` llaman a los mismos métodos sin saber el tipo. Un acierto en `PreguntaMultiple` suma bono por tiempo; en `PreguntaVerdaderoFalso` no. |
| Abstracción | `Pregunta(ABC)` con `@abstractmethod` | `modelos/pregunta.py` | Define el contrato: toda pregunta debe dar opciones, evaluarse y puntuarse. No se puede instanciar directamente (hay una prueba). Agregar un nuevo tipo solo exige implementar ese contrato. |
| Asociación | `VentanaPrincipal` ↔ `Partida`, `GestorPreguntas`, `Temporizador` | `interfaz/ventana_principal.py` | La ventana usa estos objetos pero ellos no la conocen. |
| Agregación | `GestorPreguntas` ◇— `Pregunta` | `servicios/gestor_preguntas.py` | El gestor guarda preguntas que son objetos independientes (se crean en `banco_preguntas.py` o en el diálogo). |
| Composición | `Partida` ◆— `Jugador` | `servicios/partida.py` | La partida crea su propio `Jugador` y su lista de resultados; sin partida no tienen sentido. |

Fragmento representativo del polimorfismo:

```python
# Partida.responder() no distingue tipos de pregunta
acerto = pregunta.evaluar(indice_respuesta)
if acerto:
    puntos = pregunta.calcular_puntaje(segundos_restantes, self._segundos_por_pregunta)
    self._jugador.registrar_acierto(puntos)
```

## 5. Construcción de la interfaz

**Biblioteca.** Tkinter con ttk: incluida en Python, orientada a eventos y suficiente para la aplicación.

**Diseño.** Tres pantallas que se muestran una a la vez dentro de la misma ventana (inicio, juego, resultados) y un diálogo modal para agregar preguntas. Colores y fuentes están centralizados en `estilos.py`.

**Controles.** `Entry`, `Combobox`, `Spinbox`, `Button`, `Label`, `Radiobutton`, `Treeview` con barra de desplazamiento y `messagebox`.

**Eventos y callbacks.**

| Evento | Callback |
|--------|----------|
| Clic en «Comenzar» o Enter en el nombre | `VentanaPrincipal._iniciar_partida` |
| Selección de categoría (`<<ComboboxSelected>>`) | `PantallaInicio._actualizar_maximo` |
| Clic en una opción | `VentanaPrincipal._responder(indice)` |
| Paso de cada segundo (`after`) | `Temporizador._tick` → `_al_cambiar_tiempo` |
| Fin del tiempo | `VentanaPrincipal._al_agotarse_el_tiempo` |
| Escape en el diálogo | cierra el diálogo |

**Comunicación con las clases.** Las pantallas reciben funciones por el constructor (por ejemplo, `al_responder`) y la ventana principal las conecta con `Partida`, `GestorPreguntas` y `Temporizador`.

**Capturas.**

![Inicio](imagenes/01_inicio.png)
![Juego](imagenes/02_juego.png)
![Resultados](imagenes/03_resultados.png)
![Agregar pregunta](imagenes/04_agregar_pregunta.png)

## 6. Proceso de desarrollo

1. **Formulación de la idea:** juego de preguntas de escritorio, con alcance pequeño pero completo.
2. **Identificación de funcionalidades:** configurar partida, responder con puntaje, temporizador, resultados y agregar preguntas.
3. **Diseño de clases:** se definió primero el contrato abstracto `Pregunta` y qué diferencia a cada tipo.
4. **Construcción de la lógica:** modelos y servicios, sin ninguna dependencia de Tkinter.
5. **Pruebas de la lógica:** se escribieron las pruebas automatizadas antes de conectar la interfaz.
6. **Desarrollo de la interfaz:** pantallas, controles y callbacks.
7. **Integración:** `VentanaPrincipal` conecta pantallas, partida, gestor y temporizador.
8. **Pruebas y correcciones:** pruebas automatizadas y pruebas manuales de la interfaz.

## 7. Pruebas

### 7.1 Pruebas automatizadas (pytest)

Se ejecutó `python -m pytest` con **22 pruebas aprobadas**. Algunas representativas:

| Prueba | Acción realizada | Resultado esperado | Resultado obtenido |
|--------|------------------|--------------------|--------------------|
| Prueba 1 (`test_partida_flujo_completo`) | Responder una pregunta múltiple con todo el tiempo y fallar una de verdadero/falso | 15 puntos (10 + bono 5), 50 % de efectividad, partida terminada | Aprobada |
| Prueba 2 (`test_pregunta_abstracta_no_se_puede_instanciar`) | Intentar crear `Pregunta(...)` directamente | Lanza `TypeError` | Aprobada |
| Prueba 3 (`test_multiple_valida_datos_de_entrada`) — **entrada inválida** | Crear preguntas con enunciado vacío, una sola opción, opciones repetidas o índice inválido | Cada caso lanza `ValueError` | Aprobada |
| Prueba 4 (`test_jugador_puntaje_no_se_modifica_directamente`) | Asignar `jugador.puntaje = 999` | Lanza `AttributeError` | Aprobada |
| Prueba 5 (`test_temporizador_cuenta_regresiva_y_termina`) | Simular 3 segundos con un reloj falso | Notifica 3, 2, 1, 0 y llama a `al_terminar` una vez | Aprobada |
| Prueba 6 (`test_sortear_pide_mas_de_las_que_hay`) — **entrada inválida** | Pedir 10 preguntas de una categoría con 2 | Lanza `ValueError` | Aprobada |

### 7.2 Pruebas manuales de la interfaz

> Completar la columna «Resultado obtenido» al ejecutar la aplicación.

| Prueba | Acción realizada | Resultado esperado | Resultado obtenido |
|--------|------------------|--------------------|--------------------|
| M1 | Pulsar «Comenzar» con el nombre vacío | Aviso «Escribe un nombre para poder jugar.» y no inicia | _(completar)_ |
| M2 | Responder una pregunta correctamente | La opción se pone verde y se suman puntos | _(completar)_ |
| M3 | Dejar que el tiempo llegue a cero | Mensaje «Se acabó el tiempo» y se muestra la respuesta correcta | _(completar)_ |
| M4 | Agregar una pregunta con una sola opción | Mensaje de error y la pregunta no se guarda | _(completar)_ |

## 8. Problemas y soluciones

**Problema 1: el temporizador no debe congelar la ventana.**
*Diagnóstico:* un bucle con `time.sleep` bloquea el hilo de Tkinter y la ventana deja de responder.
*Solución:* se usó el mecanismo de callbacks `after`. La clase `Temporizador` recibe `programar` y `cancelar` como funciones, por lo que no importa Tkinter y se puede probar con un reloj falso.

**Problema 2: respuestas en momentos inconsistentes.**
*Diagnóstico:* un clic justo cuando llega el tiempo a cero, o un doble clic, podía registrar dos resultados para la misma pregunta.
*Solución:* `_responder` solo actúa si `temporizador.activo` es verdadero y detiene el temporizador antes de llamar a `Partida.responder`. Además, `Partida` lanza `RuntimeError` si se responde cuando ya terminó.

**Problema 3: opciones en blanco en el formulario de preguntas.**
*Diagnóstico:* si el usuario dejaba vacía la segunda opción y marcaba la tercera como correcta, el índice ya no coincidía con la lista de textos.
*Solución:* el diálogo filtra las opciones vacías y recalcula la posición de la correcta; si no queda coherente, `PreguntaMultiple` lanza `ValueError` y se informa al usuario.

## 9. Conclusiones

El proyecto permitió aplicar de forma real los pilares de la POO: la abstracción definió un contrato claro para las preguntas, la herencia evitó duplicar código, el polimorfismo permitió que `Partida` y la interfaz ignoren el tipo concreto, y el encapsulamiento protegió el estado del jugador y de las preguntas. Separar modelos, servicios e interfaz facilitó probar la lógica sin ventanas.

**Posibles mejoras:** guardar el ranking y las preguntas en un archivo, agregar más tipos de pregunta (por ejemplo, de respuesta escrita), niveles de dificultad, sonidos y un modo de dos jugadores.
