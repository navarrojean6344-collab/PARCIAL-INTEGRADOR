import random

import pytest

from modelos import PreguntaMultiple, PreguntaVerdaderoFalso
from servicios import GestorPreguntas, Partida, Temporizador
from servicios.gestor_preguntas import TODAS


def _preguntas():
    return [
        PreguntaMultiple("¿2+2?", "Mate", ["3", "4", "5"], 1, puntos=10),
        PreguntaVerdaderoFalso("El cielo es verde.", "Mate", False, puntos=5),
    ]


# ---------------- GestorPreguntas ----------------
def test_banco_inicial_tiene_categorias_y_preguntas():
    g = GestorPreguntas()
    assert len(g.categorias()) >= 3
    assert g.total() >= 15


def test_gestor_rechaza_duplicados_y_tipos_invalidos():
    g = GestorPreguntas(_preguntas())
    with pytest.raises(ValueError):
        g.agregar(PreguntaVerdaderoFalso("¿2+2?", "Mate", True))
    with pytest.raises(TypeError):
        g.agregar("no soy una pregunta")


def test_sortear_devuelve_preguntas_distintas_de_la_categoria():
    g = GestorPreguntas()
    categoria = g.categorias()[0]
    elegidas = g.sortear(categoria, 5, generador=random.Random(1))
    assert len(elegidas) == 5
    assert len({p.enunciado for p in elegidas}) == 5
    assert all(p.categoria == categoria for p in elegidas)


def test_sortear_pide_mas_de_las_que_hay():
    g = GestorPreguntas(_preguntas())
    with pytest.raises(ValueError):
        g.sortear("Mate", 10)
    with pytest.raises(ValueError):
        g.sortear("Inexistente", 1)
    with pytest.raises(ValueError):
        g.sortear(TODAS, 0)


# ---------------- Partida ----------------
def test_partida_flujo_completo():
    partida = Partida("Ana", _preguntas(), segundos_por_pregunta=10)
    assert partida.total_preguntas == 2 and partida.numero_pregunta == 1

    r1 = partida.responder(1, segundos_restantes=10)   # acierta con todo el tiempo
    assert r1.acerto and r1.puntos_ganados == 15
    assert not partida.terminada

    r2 = partida.responder(0, segundos_restantes=4)    # "Verdadero": falla
    assert not r2.acerto and r2.puntos_ganados == 0
    assert partida.terminada
    assert partida.jugador.puntaje == 15
    assert partida.porcentaje_aciertos() == 50


def test_partida_tiempo_agotado_cuenta_como_fallo():
    partida = Partida("Ana", _preguntas(), 10)
    r = partida.tiempo_agotado()
    assert r.tiempo_agotado and r.respuesta_elegida is None
    assert partida.jugador.fallos == 1


def test_partida_terminada_no_acepta_mas_respuestas():
    partida = Partida("Ana", _preguntas()[:1], 10)
    partida.responder(1, 5)
    with pytest.raises(RuntimeError):
        partida.responder(1, 5)


def test_partida_valida_parametros():
    with pytest.raises(ValueError):
        Partida("Ana", [], 10)
    with pytest.raises(ValueError):
        Partida("Ana", _preguntas(), 1)
    with pytest.raises(ValueError):
        Partida("", _preguntas(), 10)


# ---------------- Temporizador ----------------
class RelojFalso:
    """Reemplaza a widget.after / after_cancel para probar sin ventana."""

    def __init__(self):
        self.pendientes = {}
        self._siguiente = 0

    def programar(self, ms, funcion):
        self._siguiente += 1
        self.pendientes[self._siguiente] = funcion
        return self._siguiente

    def cancelar(self, id_):
        self.pendientes.pop(id_, None)

    def avanzar_un_segundo(self):
        id_, funcion = next(iter(self.pendientes.items()))
        del self.pendientes[id_]
        funcion()


def test_temporizador_cuenta_regresiva_y_termina():
    reloj = RelojFalso()
    cambios, fin = [], []
    t = Temporizador(reloj.programar, reloj.cancelar, cambios.append, lambda: fin.append(True))
    t.iniciar(3)
    for _ in range(3):
        reloj.avanzar_un_segundo()
    assert cambios == [3, 2, 1, 0]
    assert fin == [True]
    assert not t.activo


def test_temporizador_detener_cancela_el_conteo():
    reloj = RelojFalso()
    fin = []
    t = Temporizador(reloj.programar, reloj.cancelar, lambda s: None, lambda: fin.append(True))
    t.iniciar(5)
    t.detener()
    assert reloj.pendientes == {}
    assert fin == []


def test_temporizador_rechaza_duracion_invalida():
    reloj = RelojFalso()
    t = Temporizador(reloj.programar, reloj.cancelar, lambda s: None, lambda: None)
    with pytest.raises(ValueError):
        t.iniciar(0)
