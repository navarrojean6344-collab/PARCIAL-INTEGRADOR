import pytest

from modelos import Jugador, Pregunta, PreguntaMultiple, PreguntaVerdaderoFalso


def test_pregunta_abstracta_no_se_puede_instanciar():
    with pytest.raises(TypeError):
        Pregunta("¿Hola?", "Prueba")


def test_multiple_evalua_correcta_e_incorrecta():
    p = PreguntaMultiple("¿2+2?", "Mate", ["3", "4", "5"], 1)
    assert p.evaluar(1) is True
    assert p.evaluar(0) is False
    assert p.respuesta_correcta() == "4"


def test_multiple_rechaza_indice_fuera_de_rango():
    p = PreguntaMultiple("¿2+2?", "Mate", ["3", "4"], 1)
    with pytest.raises(IndexError):
        p.evaluar(5)


def test_multiple_valida_datos_de_entrada():
    with pytest.raises(ValueError):
        PreguntaMultiple("", "Mate", ["3", "4"], 1)            # enunciado vacío
    with pytest.raises(ValueError):
        PreguntaMultiple("¿2+2?", "Mate", ["4"], 0)            # una sola opción
    with pytest.raises(ValueError):
        PreguntaMultiple("¿2+2?", "Mate", ["4", "4"], 0)       # opciones repetidas
    with pytest.raises(ValueError):
        PreguntaMultiple("¿2+2?", "Mate", ["3", "4"], 9)       # índice inválido


def test_opciones_devuelve_copia():
    p = PreguntaMultiple("¿2+2?", "Mate", ["3", "4"], 1)
    p.opciones().append("trampa")
    assert p.opciones() == ["3", "4"]


def test_verdadero_falso():
    p = PreguntaVerdaderoFalso("El agua moja.", "Ciencia", True)
    assert p.evaluar(0) is True    # Verdadero
    assert p.evaluar(1) is False   # Falso
    assert p.respuesta_correcta() == "Verdadero"
    assert p.opciones() == ["Verdadero", "Falso"]


def test_polimorfismo_en_calculo_de_puntaje():
    multiple = PreguntaMultiple("¿2+2?", "Mate", ["3", "4"], 1, puntos=10)
    vf = PreguntaVerdaderoFalso("El agua moja.", "Ciencia", True, puntos=5)
    # Mismo método, comportamiento distinto
    assert multiple.calcular_puntaje(15, 15) == 15   # 10 base + 5 de bono
    assert multiple.calcular_puntaje(0, 15) == 10    # sin bono
    assert vf.calcular_puntaje(15, 15) == 5          # nunca hay bono


def test_puntos_validados():
    with pytest.raises(ValueError):
        PreguntaVerdaderoFalso("x", "y", True, puntos=0)
    with pytest.raises(ValueError):
        PreguntaVerdaderoFalso("x", "y", True, puntos=1000)


def test_jugador_nombre_y_puntaje():
    j = Jugador("  Ana ")
    assert j.nombre == "Ana"
    j.registrar_acierto(10)
    j.registrar_acierto(7)
    j.registrar_fallo()
    assert j.puntaje == 17
    assert j.aciertos == 2 and j.fallos == 1
    assert j.racha == 0 and j.mejor_racha == 2


def test_jugador_rechaza_nombre_invalido():
    with pytest.raises(ValueError):
        Jugador("   ")
    with pytest.raises(ValueError):
        Jugador("x" * 21)


def test_jugador_puntaje_no_se_modifica_directamente():
    j = Jugador("Ana")
    with pytest.raises(AttributeError):
        j.puntaje = 999
