# 🎯 Quiz POO

Juego de preguntas y respuestas con interfaz gráfica, desarrollado en Python aplicando programación orientada a objetos.

## 1. Descripción del problema

Estudiar con apuntes o listas de preguntas es poco motivador y no da retroalimentación inmediata. Se necesitaba una herramienta sencilla de escritorio que permita **practicar conocimientos de forma interactiva**, con puntaje, límite de tiempo y una revisión final de los errores.

## 2. Objetivos

- Ofrecer un juego de preguntas por categorías con retroalimentación inmediata.
- Premiar la rapidez y llevar un registro del desempeño del jugador.
- Permitir ampliar el banco de preguntas desde la propia aplicación.
- Demostrar el uso de clases, encapsulamiento, herencia, polimorfismo, abstracción y relaciones entre objetos.

## 3. Funcionalidades

| # | Funcionalidad | Descripción |
|---|---------------|-------------|
| 1 | **Configurar y comenzar una partida** | Se escribe el nombre, se elige categoría, número de preguntas y segundos por pregunta. |
| 2 | **Responder con puntaje** | Preguntas de selección múltiple (con bono por rapidez) y de verdadero o falso. La respuesta correcta se marca en verde y la errónea en rojo. |
| 3 | **Temporizador por pregunta** | Cuenta regresiva en pantalla; al llegar a cero la pregunta cuenta como fallo. |
| 4 | **Resultados y revisión** | Puntaje final, aciertos, fallos, efectividad, mejor racha y tabla con cada respuesta. |
| 5 | **Agregar preguntas propias** | Formulario con validación para crear preguntas nuevas que entran al banco en memoria. |

Los errores previsibles (nombre vacío, valores no numéricos, pedir más preguntas de las disponibles, opciones repetidas, pregunta duplicada…) se muestran al usuario con mensajes claros.

## 4. Tecnologías utilizadas

- **Python 3.10 o superior**
- **Tkinter / ttk** (biblioteca estándar) para la interfaz gráfica
- **abc, enum, dataclasses, random** (biblioteca estándar)
- **pytest** para las pruebas automatizadas
- **Git y GitHub** para el control de versiones

No se utilizan bibliotecas externas en la aplicación; Tkinter se eligió porque viene incluido con Python y es suficiente para una interfaz orientada a eventos.

## 5. Instalación

1. Instala Python 3.10 o superior desde [python.org](https://www.python.org/downloads/). En Windows y macOS, Tkinter ya viene incluido. En Linux (Debian/Ubuntu) instálalo con:
   ```bash
   sudo apt install python3-tk
   ```
2. Clona el repositorio y entra a la carpeta:
   ```bash
   git clone <URL-DEL-REPOSITORIO>
   cd quiz_poo
   ```
3. (Opcional, solo para ejecutar las pruebas) crea un entorno virtual e instala las dependencias:
   ```bash
   python -m venv .venv
   # Windows:  .venv\Scripts\activate
   # Linux/macOS:  source .venv/bin/activate
   pip install -r requirements.txt
   ```

## 6. Ejecución

Desde la carpeta raíz del proyecto:

```bash
python main.py
```

Para correr las pruebas:

```bash
python -m pytest
```

## 7. Manual de usuario

> 📸 **Capturas:** guardar las imágenes en `docs/imagenes/` con los nombres indicados.

### 7.1 Iniciar una partida

1. Escribe tu nombre (máximo 20 caracteres).
2. Elige la categoría y el número de preguntas (el máximo depende de la categoría).
3. Define los segundos por pregunta y pulsa **Comenzar** (o presiona Enter en el campo del nombre).

![Pantalla de inicio](docs/imagenes/01_inicio.png)

### 7.2 Responder preguntas

- Haz clic en la opción que consideres correcta antes de que termine el tiempo.
- Al responder, la opción correcta se marca en verde; si fallaste, la tuya se marca en rojo.
- En las preguntas de selección múltiple ganas puntos base más un bono de hasta 5 puntos por responder rápido.

![Pantalla de juego](docs/imagenes/02_juego.png)

### 7.3 Ver los resultados

Al terminar se muestra el puntaje, la efectividad y una tabla con cada pregunta, tu respuesta y la correcta. Pulsa **Jugar de nuevo** para volver al inicio.

![Pantalla de resultados](docs/imagenes/03_resultados.png)

### 7.4 Agregar una pregunta

En la pantalla de inicio pulsa **Agregar una pregunta**, completa categoría, enunciado y tipo, y guarda. La nueva categoría aparece al instante en la lista.

![Agregar pregunta](docs/imagenes/04_agregar_pregunta.png)

## 8. Estructura del proyecto

```
quiz_poo/
├── main.py                      # Punto de entrada
├── modelos/                     # Entidades del dominio
│   ├── pregunta.py              #   Pregunta (abstracta), PreguntaMultiple, PreguntaVerdaderoFalso
│   ├── jugador.py               #   Jugador con puntaje y racha encapsulados
│   └── resultado.py             #   ResultadoRespuesta (registro inmutable)
├── servicios/                   # Lógica de aplicación (no depende de Tkinter)
│   ├── banco_preguntas.py       #   Preguntas incluidas por defecto
│   ├── gestor_preguntas.py      #   GestorPreguntas: banco, categorías y sorteo
│   ├── partida.py               #   Partida y EstadoPartida: reglas del juego
│   └── temporizador.py          #   Temporizador basado en callbacks
├── interfaz/                    # Interfaz gráfica
│   ├── ventana_principal.py     #   VentanaPrincipal: controlador de eventos
│   ├── pantalla.py              #   Pantalla: clase base de las pantallas
│   ├── pantalla_inicio.py
│   ├── pantalla_juego.py
│   ├── pantalla_resultados.py
│   ├── dialogo_pregunta.py      #   Ventana para agregar preguntas
│   └── estilos.py               #   Colores y fuentes
├── pruebas/                     # Pruebas automatizadas con pytest
├── recursos/                    # Recursos (reservado)
├── docs/
│   ├── INFORME_TECNICO.md
│   └── imagenes/
├── requirements.txt
└── README.md
```

## 9. Autor

- **[Nombre y apellidos del estudiante]** — [Programa / Curso] — [Correo]
