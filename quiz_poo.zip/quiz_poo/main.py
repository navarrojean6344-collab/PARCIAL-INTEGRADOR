"""Punto de entrada de la aplicación Quiz POO."""
from interfaz.ventana_principal import VentanaPrincipal
from servicios.gestor_preguntas import GestorPreguntas


def main() -> None:
    gestor = GestorPreguntas()
    ventana = VentanaPrincipal(gestor)
    ventana.mainloop()


if __name__ == "__main__":
    main()
